/* ============================================================
   GX-LAUNCHER 2.0 — SHARED SCRIPT
   ============================================================ */

// ===== COOKIE HELPERS =====
function getCookie(name) {
    let arr = document.cookie.split(';');
    for (let p of arr) {
        let [k, v] = p.split('=');
        if (k.trim() === name) return decodeURIComponent(v || '');
    }
    return null;
}
function setCookie(name, value, days) {
    let d = new Date();
    d.setTime(d.getTime() + days * 86400000);
    document.cookie = `${name}=${encodeURIComponent(value)};expires=${d.toUTCString()};path=/`;
}

// ===== TOAST =====
let _toastTimer;
function showToast(msg, isError) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast' + (isError ? ' error' : '') + ' show';
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}

// ===== STATUS LINE =====
function setStatus(html) {
    const el = document.getElementById('status-line');
    if (el) el.innerHTML = html;
}

// ===== LOADING OVERLAY =====
function showLoading(msg) {
    const ov = document.getElementById('loading-overlay');
    const tx = document.getElementById('loading-text');
    if (ov) ov.classList.add('active');
    if (tx) tx.textContent = msg || 'LOADING...';
    setLoadingBar(0);
}
function hideLoading() {
    const ov = document.getElementById('loading-overlay');
    if (ov) ov.classList.remove('active');
}
function setLoadingBar(pct) {
    const bar = document.getElementById('loading-bar');
    if (bar) bar.style.width = pct + '%';
}

// ===== THEME SYSTEM =====
const GX_THEMES = {
    'default':  {},
    'green':    { '--accent':'#00cc44','--accent-hi':'#00ff55','--accent-dim':'#006622','--accent-glow':'rgba(0,180,60,0.15)','--border2':'#003318' },
    'blood':    { '--accent':'#cc0000','--accent-hi':'#ff4444','--accent-dim':'#800000','--accent-glow':'rgba(200,0,0,0.22)','--border2':'#4a0000','--bg':'#080000','--bg2':'#0d0000','--bg3':'#120000','--panel':'#0f0000' },
    'midnight': { '--accent':'#5566ff','--accent-hi':'#7788ff','--accent-dim':'#2233bb','--accent-glow':'rgba(80,100,255,0.18)','--border2':'#1a2050','--bg':'#070710','--bg2':'#0c0c1a','--bg3':'#111125','--panel':'#0e0e1e' },
    'ash':      { '--accent':'#999999','--accent-hi':'#cccccc','--accent-dim':'#555555','--accent-glow':'rgba(150,150,150,0.15)','--border2':'#404040' },
    'amber':    { '--accent':'#cc7700','--accent-hi':'#ffaa00','--accent-dim':'#7a4400','--accent-glow':'rgba(200,120,0,0.18)','--border2':'#3a2200','--bg':'#090600','--bg2':'#100d00','--bg3':'#181200','--panel':'#130f00' },
};
const GX_DEFAULTS = {
    '--accent':'#cc0000','--accent-hi':'#ff2222','--accent-dim':'#7a0000',
    '--accent-glow':'rgba(180,0,0,0.18)','--bg':'#0a0a0a','--bg2':'#111111',
    '--bg3':'#181818','--panel':'#141414','--border2':'#3a0000'
};

function applyTheme(name) {
    const root = document.documentElement;
    // reset to defaults first
    for (const [k, v] of Object.entries(GX_DEFAULTS)) root.style.setProperty(k, v);
    // apply overrides
    const t = GX_THEMES[name] || {};
    for (const [k, v] of Object.entries(t)) root.style.setProperty(k, v);
    setCookie('launcherTheme', name, 365);
    // sync swatch UI if on settings page
    document.querySelectorAll('.theme-swatch').forEach(s => {
        s.classList.toggle('selected', s.dataset.themeName === name);
    });
}

// ===== MOD MAKER (removed) =====
function updateNavVisibility() {} // kept as stub so old pages don't error
function toggleModMaker() {}

// ===== VERSION SELECTOR (used on index.html) =====
let _selectedVersion = '';

function toggleVersionDropdown() {
    const dd  = document.getElementById('version-dropdown');
    const sel = document.getElementById('version-select');
    if (!dd) return;
    const isOpen = dd.classList.toggle('open');
    sel.classList.toggle('open', isOpen);
}

function selectVersion(path, label, isWasm) {
    _selectedVersion = path;
    const lbl = document.getElementById('version-label');
    if (lbl) lbl.textContent = label;
    // close dropdown
    document.getElementById('version-dropdown')?.classList.remove('open');
    document.getElementById('version-select')?.classList.remove('open');
    // enable play
    const btn = document.getElementById('play-btn');
    if (btn) btn.disabled = false;
    // highlight active option
    document.querySelectorAll('.version-option').forEach(o => o.classList.remove('active-ver'));
    if (event && event.currentTarget) event.currentTarget.classList.add('active-ver');
    // update mode badge
    const method = getCookie('launchMethod') || 'regular';
    const modeLabels = { regular:'REGULAR', 'about-blank':'ABOUT:BLANK', 'data-uri':'DATA URI', blob:'BLOB URL', popup:'POPUP' };
    const badge = document.getElementById('mode-badge-text');
    if (badge) badge.textContent = modeLabels[method] || method.toUpperCase();

    setStatus('VERSION: <span class="hl">' + label + '</span>');
}

// Close dropdown on outside click
document.addEventListener('click', e => {
    if (!e.target.closest('.version-wrapper')) {
        document.getElementById('version-dropdown')?.classList.remove('open');
        document.getElementById('version-select')?.classList.remove('open');
    }
});

// ===== LAUNCH LOGIC =====
function playGame() {
    if (!_selectedVersion) { showToast('Select a version first.', true); return; }

    const method = getCookie('launchMethod') || 'regular';
    // Build absolute URL so fetch/iframe work from any context
    const relUrl = _selectedVersion + '/index.html';
    const absUrl = new URL(relUrl, location.href).href;
    const popupFeatures = 'width=1280,height=720,toolbar=0,menubar=0,location=0,status=0';

    if (method === 'regular') {
        window.open(absUrl, '_blank');

    } else if (method === 'popup') {
        const w = window.open(absUrl, '_blank', popupFeatures);
        if (!w) showToast('Popup blocked — allow popups for this site.', true);

    } else if (method === 'about-blank') {
        const win = window.open('', '_blank');
        if (!win) { showToast('Popup blocked.', true); return; }
        win.document.open();
        win.document.write(
            '<!DOCTYPE html><html><head><style>' +
            '*{margin:0;padding:0;box-sizing:border-box}' +
            'html,body{width:100%;height:100%;overflow:hidden;background:#000}' +
            'iframe{border:none;width:100%;height:100%;display:block}' +
            '</style></head><body>' +
            '<iframe src="' + absUrl + '" allowfullscreen></iframe>' +
            '</body></html>'
        );
        win.document.close();

    } else if (method === 'blob') {
        _fetchWithProgress(absUrl).then(html => {
            const blob    = new Blob([html], { type: 'text/html' });
            const blobUrl = URL.createObjectURL(blob);
            window.open(blobUrl, '_blank');
            setStatus('LAUNCHED AS <span class="hl">BLOB URL</span>');
        }).catch(err => {
            showToast('Fetch failed: ' + err.message, true);
            setStatus('FETCH ERROR');
        });

    } else if (method === 'data-uri') {
        setStatus('FETCHING...');
        _fetchWithProgress(absUrl).then(html => {
            showLoading('ENCODING TO BASE64...');
            setTimeout(() => {
                try {
                    const b64     = btoa(unescape(encodeURIComponent(html)));
                    const dataUri = 'data:text/html;base64,' + b64;
                    hideLoading();
                    window.open(dataUri, '_blank');
                    setStatus('LAUNCHED AS <span class="hl">DATA URI</span>');
                    showToast('Launched as data: URI');
                } catch (e) {
                    hideLoading();
                    showToast('Encode failed (file may be too large or not single-file): ' + e.message, true);
                    setStatus('ENCODE ERROR');
                }
            }, 60);
        }).catch(err => {
            showToast('Fetch failed: ' + err.message, true);
            setStatus('FETCH ERROR');
        });
    }
}

function _fetchWithProgress(url) {
    showLoading('FETCHING...');
    setLoadingBar(5);
    return fetch(url).then(res => {
        if (!res.ok) { hideLoading(); throw new Error('HTTP ' + res.status); }
        const total = parseInt(res.headers.get('content-length') || '0');
        const reader = res.body.getReader();
        let received = 0;
        const chunks = [];

        function pump() {
            return reader.read().then(({ done, value }) => {
                if (done) return;
                chunks.push(value);
                received += value.length;
                if (total) setLoadingBar(5 + Math.round(received / total * 80));
                return pump();
            });
        }

        return pump().then(() => {
            setLoadingBar(88);
            const merged = new Uint8Array(received);
            let pos = 0;
            for (const c of chunks) { merged.set(c, pos); pos += c.length; }
            hideLoading();
            setLoadingBar(100);
            return new TextDecoder().decode(merged);
        });
    }).catch(err => { hideLoading(); throw err; });
}

// ===== NAVIGATION HELPERS (kept for backward compat) =====
function redirectToNews()         { window.location.href = 'news.html'; }
function redirectToClients()      { window.location.href = 'clients.html'; }
function redirectToServers()      { window.location.href = 'servers.html'; }
function redirectToMods()         { window.location.href = 'mods.html'; }
function redirectToMain()         { window.location.href = 'index.html'; }
function redirectToOtherClients() { window.location.href = 'otherclients.html'; }
function redirectToSettings()     { window.location.href = 'settings.html'; }

function openBlankPage(link) { window.open(link); }

function createAbout(url) {
    const win = window.open();
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    const iframe = win.document.createElement('iframe');
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.margin = '0';
    iframe.src = url;
    win.document.body.appendChild(iframe);
}

// ===== SETTINGS PAGE ACTIONS =====
function saveUsername() {
    const val = (document.getElementById('username-input')?.value || '').trim();
    if (!val) { showToast('Enter a username first.', true); return; }
    setCookie('username', val, 365);
    document.querySelectorAll('.profile-name, #profile-name').forEach(el => el.textContent = val);
    showToast('Username saved: ' + val);
}

function applyThemeFromSwatch(name, el) {
    applyTheme(name);
    showToast('Theme: ' + name);
}

function selectLaunchMode(mode, el) {
    setCookie('launchMethod', mode, 365);
    document.querySelectorAll('.mode-card').forEach(c => c.classList.remove('selected'));
    if (el) el.classList.add('selected');
    const labels = { regular:'REGULAR', 'about-blank':'ABOUT:BLANK', 'data-uri':'DATA URI', blob:'BLOB URL', popup:'POPUP' };
    const badge = document.getElementById('mode-badge-text');
    if (badge) badge.textContent = labels[mode] || mode.toUpperCase();
    showToast('Launch mode: ' + (labels[mode] || mode));
}

// ===== DOM READY — runs on every page =====
document.addEventListener('DOMContentLoaded', () => {

    // Apply saved username
    const username = getCookie('username');
    if (username) {
        document.querySelectorAll('.profile-name, #profile-name').forEach(el => el.textContent = username);
        const input = document.getElementById('username-input');
        if (input) input.value = username;
    }

    // Apply saved theme
    const savedTheme = getCookie('launcherTheme') || 'default';
    applyTheme(savedTheme);

    // Restore launch mode selection on settings page
    const savedMode = getCookie('launchMethod') || 'regular';
    document.querySelectorAll('.mode-card').forEach(c => {
        c.classList.toggle('selected', c.dataset.mode === savedMode);
    });
    const badge = document.getElementById('mode-badge-text');
    const modeLabels = { regular:'REGULAR', 'about-blank':'ABOUT:BLANK', 'data-uri':'DATA URI', blob:'BLOB URL', popup:'POPUP' };
    if (badge) badge.textContent = modeLabels[savedMode] || savedMode.toUpperCase();
});
